export type Headers = Record<string, string | string[]>;
