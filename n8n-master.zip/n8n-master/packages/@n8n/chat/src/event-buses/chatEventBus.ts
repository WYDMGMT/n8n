import { createEventBus } from '@/utils';

export const chatEventBus = createEventBus();
