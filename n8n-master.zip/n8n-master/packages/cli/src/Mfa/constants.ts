export const MFA_FEATURE_ENABLED = 'mfa.enabled';
